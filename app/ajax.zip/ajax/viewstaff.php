<?php 
include '../../include.php';
include '../include.php';

$request = filter_input(INPUT_POST, 'action');

if($request == "MC4yMTQyNzkwMCAxNDI3NzgxMDE1LTgtVlVrNTRZWXpTY240MlE5dXY0ZE1GaTFFNkJyV0o4a2Q="){
    $id = trim(filter_input(INPUT_POST, 'jobid', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    
    $checker = "SELECT * FROM `jb_user` WHERE id = '".$id."'";

    $query = $db->ReadData($checker);

    foreach ($query as $key => $value) {
    	$response['firstname'] = $value['firstname'];
    	$response['midname'] = $value['midname'];
    	$response['lastname'] = $value['lastname'];
    	$response['nicknake'] = $value['nicknake'];
    	$response['address'] = $value['address'];
    	$response['contact_number'] = $value['contact_number'];
    	$response['email'] = $value['email'];
    	$response['name'] = $value['name'];
        $response['username'] = $value['username'];
    	$response['job_title'] = $value['job_title'];
    	$response['created_at'] = date_format(date_create($value['created_at']), 'd M Y');
    }

    if($query) {
    		echo "{\"response\":".json_encode($response) . "}";
    }else {
        echo $db->GetErrorMessage();
    	echo "error out";
    }
}
?>